# SmolBit

Hey there! I've been working on SmolBit for a little while and felt like sharing it with the world! In the [GitHub repository](https://https://github.com/thebroskialex/SmolBit/) you can find the [documentation](https://github.com/thebroskialex/SmolBit/blob/main/DOCUMENTATION.md), [VSCode Syntax Highlighting Extension](https://github.com/thebroskialex/SmolBit/tree/main/vscode-extension), and [Python package](https://github.com/thebroskialex/SmolBit/tree/main/python-package).

I hope you enjoy it!

Installation:
`pip install SmolBit`

Usage:
`python -m SmolBit help` for package usage information