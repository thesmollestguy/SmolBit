# SmolBit

SmolBit is a programming language i've been making for a little while. This is a python package specifically made for compiling and running it.

To use the package, simply install it (it is not installable via pip yet, sorry) and run `python -m SmolBit` with any additional arguments needed.